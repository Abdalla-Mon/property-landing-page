// Import necessary modules
const express = require('express');
const path = require('path');
const cors = require('cors');
const multer = require('multer');

// Create Express application
const app = express();
const hostname = "www.modernlife-s.com";

// Set up storage for uploaded files
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'public/uploads/'); // Destination folder for uploaded images
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)); // Rename file to avoid overwriting
    }
});
const upload = multer({ storage: storage });

// Serve static files from the 'public' directory
app.use(cors());
app.use(express.json());
app.use(express.static("public"));



// Define /projects route
app.route('/projects')
      .get((req, res) => {
          console.log('GET /projects');
          // Logic to retrieve projects can be added here
          res.send('GET request to /projects');
      })
      .post(upload.array('files'), (req, res) => {
          console.log('POST /projects');
          console.log('Body:', req.body);
          console.log('Files:', req.files);
          // Logic to create a new project can be added here
          res.send('POST request to /projects');
      })
      .put((req, res) => {
          console.log('PUT /projects');
          console.log('Body:', req.body);
          // Logic to update a project can be added here
          res.send('PUT request to /projects');
      })
      .delete((req, res) => {
          console.log('DELETE /projects');
          console.log('Body:', req.body);
          // Logic to delete a project can be added here
          res.send('DELETE request to /projects');
      });

// Error handling middleware
app.use((err, req, res, next) => {
    console.error("Error occurred:", err);
    res.status(500).send("Internal Server Error");
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://${hostname}:${PORT}`);
});
